﻿namespace CompanySoftware
{
    partial class companySoftwareMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(companySoftwareMenu));
            this.employeeStripImage = new System.Windows.Forms.ToolStripButton();
            this.employeeStripLabel = new System.Windows.Forms.ToolStripLabel();
            this.inventoryStripImage = new System.Windows.Forms.ToolStripButton();
            this.inventoryStripLabel = new System.Windows.Forms.ToolStripLabel();
            this.invoiceStripImage = new System.Windows.Forms.ToolStripButton();
            this.invoiceStripLabel = new System.Windows.Forms.ToolStripLabel();
            this.sideBarStrip = new System.Windows.Forms.ToolStrip();
            this.exitStripImage = new System.Windows.Forms.ToolStripButton();
            this.exitStripLabel = new System.Windows.Forms.ToolStripLabel();
            this.companyDataSet = new CompanySoftware.CompanyDataSet();
            this.companyDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tableBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tableTableAdapter = new CompanySoftware.CompanyDataSetTableAdapters.TableTableAdapter();
            this.productBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.productTableAdapter = new CompanySoftware.CompanyDataSetTableAdapters.ProductTableAdapter();
            this.sideBarStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.companyDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.companyDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // employeeStripImage
            // 
            this.employeeStripImage.AutoSize = false;
            this.employeeStripImage.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.employeeStripImage.Image = ((System.Drawing.Image)(resources.GetObject("employeeStripImage.Image")));
            this.employeeStripImage.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.employeeStripImage.Name = "employeeStripImage";
            this.employeeStripImage.Size = new System.Drawing.Size(100, 50);
            this.employeeStripImage.Text = "Employee";
            // 
            // employeeStripLabel
            // 
            this.employeeStripLabel.Name = "employeeStripLabel";
            this.employeeStripLabel.Size = new System.Drawing.Size(162, 20);
            this.employeeStripLabel.Text = "Employees";
            // 
            // inventoryStripImage
            // 
            this.inventoryStripImage.AutoSize = false;
            this.inventoryStripImage.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.inventoryStripImage.Image = ((System.Drawing.Image)(resources.GetObject("inventoryStripImage.Image")));
            this.inventoryStripImage.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.inventoryStripImage.Name = "inventoryStripImage";
            this.inventoryStripImage.Size = new System.Drawing.Size(100, 50);
            this.inventoryStripImage.Text = "toolStripButton1";
            // 
            // inventoryStripLabel
            // 
            this.inventoryStripLabel.Name = "inventoryStripLabel";
            this.inventoryStripLabel.Size = new System.Drawing.Size(162, 20);
            this.inventoryStripLabel.Text = "Inventory";
            // 
            // invoiceStripImage
            // 
            this.invoiceStripImage.AutoSize = false;
            this.invoiceStripImage.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.invoiceStripImage.Image = ((System.Drawing.Image)(resources.GetObject("invoiceStripImage.Image")));
            this.invoiceStripImage.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.invoiceStripImage.Name = "invoiceStripImage";
            this.invoiceStripImage.Size = new System.Drawing.Size(100, 50);
            this.invoiceStripImage.Text = "toolStripButton2";
            // 
            // invoiceStripLabel
            // 
            this.invoiceStripLabel.ActiveLinkColor = System.Drawing.Color.Red;
            this.invoiceStripLabel.Name = "invoiceStripLabel";
            this.invoiceStripLabel.Size = new System.Drawing.Size(162, 20);
            this.invoiceStripLabel.Text = "Invoices";
            // 
            // sideBarStrip
            // 
            this.sideBarStrip.AutoSize = false;
            this.sideBarStrip.BackColor = System.Drawing.Color.Silver;
            this.sideBarStrip.Dock = System.Windows.Forms.DockStyle.Left;
            this.sideBarStrip.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.sideBarStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.employeeStripImage,
            this.employeeStripLabel,
            this.inventoryStripImage,
            this.inventoryStripLabel,
            this.invoiceStripImage,
            this.invoiceStripLabel,
            this.exitStripImage,
            this.exitStripLabel});
            this.sideBarStrip.Location = new System.Drawing.Point(0, 0);
            this.sideBarStrip.Name = "sideBarStrip";
            this.sideBarStrip.Size = new System.Drawing.Size(164, 720);
            this.sideBarStrip.TabIndex = 0;
            this.sideBarStrip.Text = "toolStrip1";
            // 
            // exitStripImage
            // 
            this.exitStripImage.AutoSize = false;
            this.exitStripImage.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.exitStripImage.Image = ((System.Drawing.Image)(resources.GetObject("exitStripImage.Image")));
            this.exitStripImage.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.exitStripImage.Name = "exitStripImage";
            this.exitStripImage.Size = new System.Drawing.Size(87, 50);
            this.exitStripImage.Click += new System.EventHandler(this.exitStripImage_Click);
            // 
            // exitStripLabel
            // 
            this.exitStripLabel.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.exitStripLabel.Name = "exitStripLabel";
            this.exitStripLabel.Size = new System.Drawing.Size(162, 20);
            this.exitStripLabel.Text = "Exit";
            // 
            // companyDataSet
            // 
            this.companyDataSet.DataSetName = "CompanyDataSet";
            this.companyDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // companyDataSetBindingSource
            // 
            this.companyDataSetBindingSource.DataSource = this.companyDataSet;
            this.companyDataSetBindingSource.Position = 0;
            // 
            // tableBindingSource
            // 
            this.tableBindingSource.DataMember = "Table";
            this.tableBindingSource.DataSource = this.companyDataSetBindingSource;
            // 
            // tableTableAdapter
            // 
            this.tableTableAdapter.ClearBeforeFill = true;
            // 
            // productBindingSource
            // 
            this.productBindingSource.DataMember = "Product";
            this.productBindingSource.DataSource = this.companyDataSetBindingSource;
            // 
            // productTableAdapter
            // 
            this.productTableAdapter.ClearBeforeFill = true;
            // 
            // companySoftwareMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.ClientSize = new System.Drawing.Size(1281, 720);
            this.Controls.Add(this.sideBarStrip);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "companySoftwareMenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = " ";
            this.Load += new System.EventHandler(this.companySoftware_Load);
            this.sideBarStrip.ResumeLayout(false);
            this.sideBarStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.companyDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.companyDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.ToolStripButton employeeStripImage;
        private System.Windows.Forms.ToolStripLabel employeeStripLabel;
        private System.Windows.Forms.ToolStripButton inventoryStripImage;
        private System.Windows.Forms.ToolStripLabel inventoryStripLabel;
        private System.Windows.Forms.ToolStripButton invoiceStripImage;
        private System.Windows.Forms.ToolStripLabel invoiceStripLabel;
        private System.Windows.Forms.ToolStrip sideBarStrip;
        private System.Windows.Forms.ToolStripButton exitStripImage;
        private System.Windows.Forms.ToolStripLabel exitStripLabel;
        private System.Windows.Forms.BindingSource companyDataSetBindingSource;
        private CompanyDataSet companyDataSet;
        private System.Windows.Forms.BindingSource tableBindingSource;
        private CompanyDataSetTableAdapters.TableTableAdapter tableTableAdapter;
        private System.Windows.Forms.BindingSource productBindingSource;
        private CompanyDataSetTableAdapters.ProductTableAdapter productTableAdapter;
    }
}