﻿namespace CompanySoftware
{
    partial class companySoftwareInventory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(companySoftwareInventory));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.employeeStripImage = new System.Windows.Forms.ToolStripButton();
            this.employeeStripLabel = new System.Windows.Forms.ToolStripLabel();
            this.inventoryStripImage = new System.Windows.Forms.ToolStripButton();
            this.inventoryStripLabel = new System.Windows.Forms.ToolStripLabel();
            this.invoiceStripImage = new System.Windows.Forms.ToolStripButton();
            this.invoiceStripLabel = new System.Windows.Forms.ToolStripLabel();
            this.sideBarStrip = new System.Windows.Forms.ToolStrip();
            this.exitStripImage = new System.Windows.Forms.ToolStripButton();
            this.exitStripLabel = new System.Windows.Forms.ToolStripLabel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.productidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productquantityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productcategoryDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productpriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.companyDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.companyDataSet = new CompanySoftware.CompanyDataSet();
            this.tableBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tableTableAdapter = new CompanySoftware.CompanyDataSetTableAdapters.TableTableAdapter();
            this.productTableAdapter = new CompanySoftware.CompanyDataSetTableAdapters.ProductTableAdapter();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.btnClearProduct = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtLowPrice = new System.Windows.Forms.TextBox();
            this.txtHighPrice = new System.Windows.Forms.TextBox();
            this.btnSearchPrice = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.sideBarStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.companyDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.companyDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableBindingSource)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // employeeStripImage
            // 
            this.employeeStripImage.AutoSize = false;
            this.employeeStripImage.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.employeeStripImage.Image = ((System.Drawing.Image)(resources.GetObject("employeeStripImage.Image")));
            this.employeeStripImage.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.employeeStripImage.Name = "employeeStripImage";
            this.employeeStripImage.Size = new System.Drawing.Size(100, 50);
            this.employeeStripImage.Text = "Employee";
            this.employeeStripImage.Click += new System.EventHandler(this.employeeImage_Click);
            // 
            // employeeStripLabel
            // 
            this.employeeStripLabel.Name = "employeeStripLabel";
            this.employeeStripLabel.Size = new System.Drawing.Size(121, 15);
            this.employeeStripLabel.Text = "Employees";
            // 
            // inventoryStripImage
            // 
            this.inventoryStripImage.AutoSize = false;
            this.inventoryStripImage.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.inventoryStripImage.Image = ((System.Drawing.Image)(resources.GetObject("inventoryStripImage.Image")));
            this.inventoryStripImage.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.inventoryStripImage.Name = "inventoryStripImage";
            this.inventoryStripImage.Size = new System.Drawing.Size(100, 50);
            this.inventoryStripImage.Text = "toolStripButton1";
            // 
            // inventoryStripLabel
            // 
            this.inventoryStripLabel.Name = "inventoryStripLabel";
            this.inventoryStripLabel.Size = new System.Drawing.Size(121, 15);
            this.inventoryStripLabel.Text = "Inventory";
            // 
            // invoiceStripImage
            // 
            this.invoiceStripImage.AutoSize = false;
            this.invoiceStripImage.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.invoiceStripImage.Image = ((System.Drawing.Image)(resources.GetObject("invoiceStripImage.Image")));
            this.invoiceStripImage.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.invoiceStripImage.Name = "invoiceStripImage";
            this.invoiceStripImage.Size = new System.Drawing.Size(100, 50);
            this.invoiceStripImage.Text = "toolStripButton2";
            // 
            // invoiceStripLabel
            // 
            this.invoiceStripLabel.ActiveLinkColor = System.Drawing.Color.Red;
            this.invoiceStripLabel.Name = "invoiceStripLabel";
            this.invoiceStripLabel.Size = new System.Drawing.Size(121, 15);
            this.invoiceStripLabel.Text = "Invoices";
            // 
            // sideBarStrip
            // 
            this.sideBarStrip.AutoSize = false;
            this.sideBarStrip.BackColor = System.Drawing.Color.Silver;
            this.sideBarStrip.Dock = System.Windows.Forms.DockStyle.Left;
            this.sideBarStrip.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.sideBarStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.employeeStripImage,
            this.employeeStripLabel,
            this.inventoryStripImage,
            this.inventoryStripLabel,
            this.invoiceStripImage,
            this.invoiceStripLabel,
            this.exitStripImage,
            this.exitStripLabel});
            this.sideBarStrip.Location = new System.Drawing.Point(0, 0);
            this.sideBarStrip.Name = "sideBarStrip";
            this.sideBarStrip.Size = new System.Drawing.Size(123, 585);
            this.sideBarStrip.TabIndex = 0;
            this.sideBarStrip.Text = "toolStrip1";
            this.sideBarStrip.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.sideBarStrip_ItemClicked);
            // 
            // exitStripImage
            // 
            this.exitStripImage.AutoSize = false;
            this.exitStripImage.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.exitStripImage.Image = ((System.Drawing.Image)(resources.GetObject("exitStripImage.Image")));
            this.exitStripImage.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.exitStripImage.Name = "exitStripImage";
            this.exitStripImage.Size = new System.Drawing.Size(87, 50);
            this.exitStripImage.Click += new System.EventHandler(this.exitStripImage_Click);
            // 
            // exitStripLabel
            // 
            this.exitStripLabel.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.exitStripLabel.Name = "exitStripLabel";
            this.exitStripLabel.Size = new System.Drawing.Size(121, 15);
            this.exitStripLabel.Text = "Exit";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToOrderColumns = true;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.productidDataGridViewTextBoxColumn,
            this.productnameDataGridViewTextBoxColumn,
            this.productquantityDataGridViewTextBoxColumn,
            this.productcategoryDataGridViewTextBoxColumn,
            this.productpriceDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.productBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(38, 166);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(752, 388);
            this.dataGridView1.TabIndex = 1;
            // 
            // productidDataGridViewTextBoxColumn
            // 
            this.productidDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.productidDataGridViewTextBoxColumn.DataPropertyName = "product_id";
            this.productidDataGridViewTextBoxColumn.HeaderText = "product_id";
            this.productidDataGridViewTextBoxColumn.Name = "productidDataGridViewTextBoxColumn";
            this.productidDataGridViewTextBoxColumn.Width = 82;
            // 
            // productnameDataGridViewTextBoxColumn
            // 
            this.productnameDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.productnameDataGridViewTextBoxColumn.DataPropertyName = "product_name";
            this.productnameDataGridViewTextBoxColumn.HeaderText = "product_name";
            this.productnameDataGridViewTextBoxColumn.Name = "productnameDataGridViewTextBoxColumn";
            // 
            // productquantityDataGridViewTextBoxColumn
            // 
            this.productquantityDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.productquantityDataGridViewTextBoxColumn.DataPropertyName = "product_quantity";
            this.productquantityDataGridViewTextBoxColumn.HeaderText = "product_quantity";
            this.productquantityDataGridViewTextBoxColumn.Name = "productquantityDataGridViewTextBoxColumn";
            this.productquantityDataGridViewTextBoxColumn.Width = 111;
            // 
            // productcategoryDataGridViewTextBoxColumn
            // 
            this.productcategoryDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.productcategoryDataGridViewTextBoxColumn.DataPropertyName = "product_category";
            this.productcategoryDataGridViewTextBoxColumn.HeaderText = "product_category";
            this.productcategoryDataGridViewTextBoxColumn.Name = "productcategoryDataGridViewTextBoxColumn";
            this.productcategoryDataGridViewTextBoxColumn.Width = 115;
            // 
            // productpriceDataGridViewTextBoxColumn
            // 
            this.productpriceDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.productpriceDataGridViewTextBoxColumn.DataPropertyName = "product_price";
            dataGridViewCellStyle1.Format = "C2";
            dataGridViewCellStyle1.NullValue = null;
            this.productpriceDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle1;
            this.productpriceDataGridViewTextBoxColumn.HeaderText = "product_price";
            this.productpriceDataGridViewTextBoxColumn.Name = "productpriceDataGridViewTextBoxColumn";
            this.productpriceDataGridViewTextBoxColumn.Width = 97;
            // 
            // productBindingSource
            // 
            this.productBindingSource.DataMember = "Product";
            this.productBindingSource.DataSource = this.companyDataSetBindingSource;
            // 
            // companyDataSetBindingSource
            // 
            this.companyDataSetBindingSource.DataSource = this.companyDataSet;
            this.companyDataSetBindingSource.Position = 0;
            // 
            // companyDataSet
            // 
            this.companyDataSet.DataSetName = "CompanyDataSet";
            this.companyDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tableBindingSource
            // 
            this.tableBindingSource.DataMember = "Table";
            this.tableBindingSource.DataSource = this.companyDataSetBindingSource;
            // 
            // tableTableAdapter
            // 
            this.tableTableAdapter.ClearBeforeFill = true;
            // 
            // productTableAdapter
            // 
            this.productTableAdapter.ClearBeforeFill = true;
            // 
            // txtSearch
            // 
            this.txtSearch.Location = new System.Drawing.Point(114, 15);
            this.txtSearch.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(194, 20);
            this.txtSearch.TabIndex = 2;
            this.txtSearch.TextChanged += new System.EventHandler(this.txtSearch_TextChanged);
            // 
            // btnClearProduct
            // 
            this.btnClearProduct.BackColor = System.Drawing.Color.White;
            this.btnClearProduct.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnClearProduct.BackgroundImage")));
            this.btnClearProduct.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnClearProduct.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClearProduct.Location = new System.Drawing.Point(290, 15);
            this.btnClearProduct.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnClearProduct.Name = "btnClearProduct";
            this.btnClearProduct.Size = new System.Drawing.Size(16, 18);
            this.btnClearProduct.TabIndex = 3;
            this.btnClearProduct.UseVisualStyleBackColor = false;
            this.btnClearProduct.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(8, 17);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 15);
            this.label1.TabIndex = 4;
            this.label1.Text = "Search Product";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(8, 58);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(106, 15);
            this.label2.TabIndex = 5;
            this.label2.Text = "Define Price Range";
            // 
            // txtLowPrice
            // 
            this.txtLowPrice.Location = new System.Drawing.Point(114, 58);
            this.txtLowPrice.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtLowPrice.Name = "txtLowPrice";
            this.txtLowPrice.Size = new System.Drawing.Size(76, 20);
            this.txtLowPrice.TabIndex = 6;
            // 
            // txtHighPrice
            // 
            this.txtHighPrice.Location = new System.Drawing.Point(232, 58);
            this.txtHighPrice.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtHighPrice.Name = "txtHighPrice";
            this.txtHighPrice.Size = new System.Drawing.Size(76, 20);
            this.txtHighPrice.TabIndex = 7;
            // 
            // btnSearchPrice
            // 
            this.btnSearchPrice.BackColor = System.Drawing.Color.White;
            this.btnSearchPrice.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSearchPrice.BackgroundImage")));
            this.btnSearchPrice.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSearchPrice.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSearchPrice.Location = new System.Drawing.Point(460, 60);
            this.btnSearchPrice.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnSearchPrice.Name = "btnSearchPrice";
            this.btnSearchPrice.Size = new System.Drawing.Size(29, 21);
            this.btnSearchPrice.TabIndex = 8;
            this.btnSearchPrice.UseVisualStyleBackColor = false;
            this.btnSearchPrice.Click += new System.EventHandler(this.btnSearchPrice_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(328, 60);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 15);
            this.label3.TabIndex = 9;
            this.label3.Text = "Category";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.comboBox1);
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.btnSearchPrice);
            this.panel1.Controls.Add(this.txtHighPrice);
            this.panel1.Controls.Add(this.txtLowPrice);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.btnClearProduct);
            this.panel1.Controls.Add(this.txtSearch);
            this.panel1.Location = new System.Drawing.Point(141, 11);
            this.panel1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(840, 574);
            this.panel1.TabIndex = 11;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(387, 60);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(76, 21);
            this.comboBox1.TabIndex = 10;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // companySoftwareInventory
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.ClientSize = new System.Drawing.Size(961, 585);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.sideBarStrip);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "companySoftwareInventory";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = " ";
            this.Load += new System.EventHandler(this.companySoftware_Load);
            this.sideBarStrip.ResumeLayout(false);
            this.sideBarStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.companyDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.companyDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableBindingSource)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.ToolStripButton employeeStripImage;
        private System.Windows.Forms.ToolStripLabel employeeStripLabel;
        private System.Windows.Forms.ToolStripButton inventoryStripImage;
        private System.Windows.Forms.ToolStripLabel inventoryStripLabel;
        private System.Windows.Forms.ToolStripButton invoiceStripImage;
        private System.Windows.Forms.ToolStripLabel invoiceStripLabel;
        private System.Windows.Forms.ToolStrip sideBarStrip;
        private System.Windows.Forms.ToolStripButton exitStripImage;
        private System.Windows.Forms.ToolStripLabel exitStripLabel;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.BindingSource companyDataSetBindingSource;
        private CompanyDataSet companyDataSet;
        private System.Windows.Forms.BindingSource tableBindingSource;
        private CompanyDataSetTableAdapters.TableTableAdapter tableTableAdapter;
        private System.Windows.Forms.BindingSource productBindingSource;
        private CompanyDataSetTableAdapters.ProductTableAdapter productTableAdapter;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.DataGridViewTextBoxColumn productidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn productnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn productquantityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn productcategoryDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn productpriceDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button btnClearProduct;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtLowPrice;
        private System.Windows.Forms.TextBox txtHighPrice;
        private System.Windows.Forms.Button btnSearchPrice;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox comboBox1;
    }
}