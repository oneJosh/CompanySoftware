﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CompanySoftware
{
    public partial class companySoftwareMenu : Form
    {
        public companySoftwareMenu()
        {
            InitializeComponent();
        }
        private void exitStripImage_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }

        private void companySoftware_Load(object sender, EventArgs e)
        {
        }
    }

   

}

